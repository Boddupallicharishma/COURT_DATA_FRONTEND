document.getElementById("caseForm").addEventListener("submit", function(event) {
  event.preventDefault();

  const type = document.getElementById("caseType").value.trim();
  const number = document.getElementById("caseNumber").value.trim();
  const year = document.getElementById("caseYear").value.trim();

  fetch("cases.json")
    .then(response => response.json())
    .then(data => {
      const result = data.find(
        caseItem =>
          caseItem.type.toLowerCase() === type.toLowerCase() &&
          caseItem.number.toString() === number &&
          caseItem.year.toString() === year
      );

      const resultsDiv = document.getElementById("results");

      if (result) {
        resultsDiv.innerHTML = `
          <h2>Case Found ✅</h2>
          <p><strong>Case:</strong> ${result.type} ${result.number}/${result.year}</p>
          <p><strong>Petitioner:</strong> ${result.petitioner}</p>
          <p><strong>Respondent:</strong> ${result.respondent}</p>
          <p><a href="${result.pdf}" target="_blank">📄 View Judgment</a></p>
        `;
      } else {
        resultsDiv.innerHTML = `<h2>No matching case found ❌</h2>`;
      }
    })
    .catch(err => console.error("Error loading data:", err));
});